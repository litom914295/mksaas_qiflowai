# Technical Documentation: FengShuiCompass Integration

## 1. Architecture Overview

### System Architecture

```mermaid
graph TB
    subgraph "Frontend Layer"
        A[React Components] --> B[Compass Engine]
        B --> C[Sensor Fusion]
        C --> D[Device APIs]
    end

    subgraph "Service Layer"
        E[API Gateway] --> F[Compass Service]
        F --> G[AI Analysis Engine]
        F --> H[Calculation Engine]
    end

    subgraph "Data Layer"
        I[Supabase DB] --> J[Measurements]
        I --> K[Calibrations]
        I --> L[User Profiles]
    end

    A --> E
    F --> I
    G --> M[OpenAI/Claude]
    H --> N[Flying Stars Engine]
```

### Component Hierarchy

```
src/
├── components/
│   └── compass/
│       ├── FengShuiCompass.tsx           # Main compass component
│       ├── CompassLayer.tsx              # Individual layer rendering
│       ├── CompassControls.tsx           # User controls
│       ├── SensorCalibration.tsx         # Calibration UI
│       └── CompassAnalysis.tsx           # AI analysis display
├── lib/
│   ├── compass/
│   │   ├── sensor-fusion.ts              # Sensor data processing
│   │   ├── magnetic-declination.ts       # Declination calculations
│   │   └── compass-calculations.ts       # Core compass math
│   └── integrations/
│       └── feng-shui-compass.ts          # Integration layer
└── types/
    └── feng-shui-compass.ts              # TypeScript definitions
```

## 2. Migration Strategy (Vue → React)

### Phase 1: Analysis & Preparation (Week 1)

**Component Mapping:**
| Vue Component | React Equivalent | Migration Complexity |
|---------------|------------------|---------------------|
| `FengShuiCompass.vue` | `FengShuiCompass.tsx` | High - Core logic |
| `CompassLayer.vue` | `CompassLayer.tsx` | Medium - Rendering |
| `SensorManager.js` | `useSensorFusion.ts` | High - Hook conversion |
| `CompassData.js` | `compass-data.ts` | Low - Data structure |

**Template to JSX Conversion:**
```typescript
// Vue Template
<template>
  <div class="compass-container" :style="{ transform: `rotate(${rotation}deg)` }">
    <svg :width="size" :height="size">
      <g v-for="(layer, index) in layers" :key="index">
        <!-- Layer rendering -->
      </g>
    </svg>
  </div>
</template>

// React JSX
const FengShuiCompass: React.FC<FengShuiCompassProps> = ({ size, rotation, layers }) => {
  return (
    <div className="compass-container" style={{ transform: `rotate(${rotation}deg)` }}>
      <svg width={size} height={size}>
        {layers.map((layer, index) => (
          <CompassLayer key={index} layer={layer} />
        ))}
      </svg>
    </div>
  );
};
```

**Composition API to Hooks:**
```typescript
// Vue Composition API
export default defineComponent({
  setup() {
    const rotation = ref(0);
    const isCalibrating = ref(false);

    const handleSensorData = (data: SensorData) => {
      rotation.value = data.heading;
    };

    return { rotation, isCalibrating, handleSensorData };
  }
});

// React Hooks
export const useFengShuiCompass = () => {
  const [rotation, setRotation] = useState(0);
  const [isCalibrating, setIsCalibrating] = useState(false);

  const handleSensorData = useCallback((data: SensorData) => {
    setRotation(data.heading);
  }, []);

  return { rotation, isCalibrating, handleSensorData };
};
```

### Phase 2: Core Migration (Weeks 2-3)

**State Management Integration:**
```typescript
// Zustand Store for Compass State
interface CompassStore {
  // State
  rotation: number;
  isCalibrated: boolean;
  sensorAvailable: boolean;
  measurements: CompassMeasurement[];

  // Actions
  setRotation: (rotation: number) => void;
  addMeasurement: (measurement: CompassMeasurement) => void;
  calibrateSensors: () => Promise<void>;
  reset: () => void;
}

export const useCompassStore = create<CompassStore>((set, get) => ({
  rotation: 0,
  isCalibrated: false,
  sensorAvailable: false,
  measurements: [],

  setRotation: (rotation) => set({ rotation }),
  addMeasurement: (measurement) =>
    set(state => ({ measurements: [...state.measurements, measurement] })),
  calibrateSensors: async () => {
    // Calibration logic
    set({ isCalibrated: true });
  },
  reset: () => set({ rotation: 0, measurements: [] })
}));
```

### Phase 3: Integration (Week 4)

**Next.js App Router Integration:**
```typescript
// app/compass/page.tsx
export default function CompassPage() {
  return (
    <Suspense fallback={<CompassSkeleton />}>
      <FengShuiCompass />
    </Suspense>
  );
}

// Dynamic import for client-side only features
const FengShuiCompass = dynamic(
  () => import('@/components/compass/FengShuiCompass'),
  { ssr: false }
);
```

## 3. API Specifications

### REST Endpoints

```typescript
// API Route: /api/compass/measurements
interface CompassMeasurementRequest {
  latitude: number;
  longitude: number;
  magneticHeading: number;
  trueHeading: number;
  timestamp: string;
  userId?: string;
  sessionId: string;
}

interface CompassMeasurementResponse {
  id: string;
  measurement: CompassMeasurement;
  analysis: FengShuiAnalysis;
  confidence: number;
}

// API Route: /api/compass/calibration
interface CalibrationRequest {
  deviceId: string;
  sensorData: SensorReading[];
  calibrationMethod: 'figure8' | 'manual' | 'automatic';
}

interface CalibrationResponse {
  calibrationId: string;
  success: boolean;
  accuracy: number;
  recommendations: string[];
}
```

### WebSocket Events

```typescript
// Real-time compass updates
interface CompassSocketEvents {
  'compass:heading_update': {
    heading: number;
    accuracy: number;
    timestamp: number;
  };

  'compass:calibration_status': {
    status: 'in_progress' | 'completed' | 'failed';
    progress: number;
    instructions: string;
  };

  'compass:analysis_result': {
    measurementId: string;
    analysis: FengShuiAnalysis;
    recommendations: Recommendation[];
  };
}
```

### TypeScript Interfaces

```typescript
interface FengShuiCompassConfig {
  size: number;
  layers: CompassLayer[];
  theme: CompassTheme;
  sensorConfig: SensorConfig;
  permissions: CompassPermissions;
}

interface CompassLayer {
  id: string;
  name: string | string[];
  data: string[] | string[][];
  startAngle: number;
  fontSize: number;
  textColor: string | string[];
  vertical: boolean;
  togetherStyle: 'empty' | 'equally';
  shape: 'circle' | 'polygon';
  visible: boolean;
}

interface SensorConfig {
  enableMagnetometer: boolean;
  enableGyroscope: boolean;
  enableAccelerometer: boolean;
  fusionAlgorithm: 'kalman' | 'complementary' | 'simple';
  updateFrequency: number; // Hz
}

interface CompassMeasurement {
  id: string;
  userId?: string;
  sessionId: string;
  timestamp: Date;
  location: GeoLocation;
  magneticHeading: number;
  trueHeading: number;
  declination: number;
  accuracy: number;
  deviceInfo: DeviceInfo;
  metadata: Record<string, any>;
}
```

## 4. Database Schema

### PostgreSQL Tables

```sql
-- Compass measurements with time-series optimization
CREATE TABLE compass_measurements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id),
    session_id UUID NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),

    -- Location data (encrypted)
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    altitude DECIMAL(8, 2),
    location_accuracy DECIMAL(6, 2),

    -- Compass readings
    magnetic_heading DECIMAL(5, 2) NOT NULL CHECK (magnetic_heading >= 0 AND magnetic_heading < 360),
    true_heading DECIMAL(5, 2) NOT NULL CHECK (true_heading >= 0 AND true_heading < 360),
    magnetic_declination DECIMAL(5, 2) NOT NULL,
    reading_accuracy DECIMAL(4, 2),

    -- Device information
    device_type TEXT,
    device_model TEXT,
    user_agent TEXT,
    sensor_capabilities JSONB,

    -- Feng shui analysis
    flying_stars_period INTEGER CHECK (flying_stars_period BETWEEN 1 AND 9),
    sector_analysis JSONB,
    ai_analysis_id UUID,

    -- Metadata
    notes TEXT,
    tags TEXT[],
    metadata JSONB DEFAULT '{}'::jsonb
);

-- Sensor calibration data
CREATE TABLE compass_calibrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id),
    device_id TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),

    -- Calibration method and results
    calibration_method TEXT NOT NULL CHECK (calibration_method IN ('figure8', 'manual', 'automatic')),
    calibration_data JSONB NOT NULL,
    accuracy_score DECIMAL(4, 2) CHECK (accuracy_score BETWEEN 0 AND 100),

    -- Validation
    validation_measurements JSONB,
    is_active BOOLEAN DEFAULT true,
    expires_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '30 days'),

    -- Quality metrics
    hard_iron_offset JSONB,
    soft_iron_matrix JSONB,
    noise_level DECIMAL(6, 4)
);

-- House orientations for feng shui analysis
CREATE TABLE house_orientations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),

    -- House identification
    house_name TEXT,
    address TEXT,
    coordinates POINT, -- PostGIS extension

    -- Orientation data
    front_door_heading DECIMAL(5, 2) NOT NULL,
    building_facing DECIMAL(5, 2) NOT NULL,
    magnetic_declination DECIMAL(5, 2) NOT NULL,
    measurement_date TIMESTAMPTZ NOT NULL,

    -- Feng shui calculations
    sitting_mountain TEXT,
    facing_direction TEXT,
    flying_stars_chart JSONB,
    bazi_compatibility JSONB,

    -- Analysis results
    ai_analysis JSONB,
    recommendations JSONB,
    analysis_confidence DECIMAL(3, 2),

    -- Metadata
    floor_plan_url TEXT,
    photos TEXT[],
    notes TEXT,
    is_verified BOOLEAN DEFAULT false
);
```

### Indexes for Performance

```sql
-- Time-series queries
CREATE INDEX idx_compass_measurements_created_at
ON compass_measurements (created_at DESC);

-- User-specific queries
CREATE INDEX idx_compass_measurements_user_session
ON compass_measurements (user_id, session_id, created_at DESC);

-- Location-based queries (PostGIS)
CREATE INDEX idx_house_orientations_location
ON house_orientations USING GIST (coordinates);

-- Analysis lookups
CREATE INDEX idx_compass_measurements_analysis
ON compass_measurements (ai_analysis_id)
WHERE ai_analysis_id IS NOT NULL;

-- Device calibration
CREATE INDEX idx_compass_calibrations_device
ON compass_calibrations (device_id, is_active, expires_at);
```

### Row Level Security (RLS)

```sql
-- Enable RLS
ALTER TABLE compass_measurements ENABLE ROW LEVEL SECURITY;
ALTER TABLE compass_calibrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE house_orientations ENABLE ROW LEVEL SECURITY;

-- User access policies
CREATE POLICY "Users can view own compass measurements"
ON compass_measurements FOR SELECT
USING (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Users can insert own compass measurements"
ON compass_measurements FOR INSERT
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- Guest access for anonymous measurements
CREATE POLICY "Anonymous measurements allowed"
ON compass_measurements FOR ALL
USING (user_id IS NULL);

-- Calibration data policies
CREATE POLICY "Users can manage own calibrations"
ON compass_calibrations FOR ALL
USING (auth.uid() = user_id);
```

## 5. Sensor Integration

### Sensor Fusion Architecture

```typescript
class SensorFusionEngine {
  private magnetometer: MagnetometerReading | null = null;
  private gyroscope: GyroscopeReading | null = null;
  private accelerometer: AccelerometerReading | null = null;

  private kalmanFilter: KalmanFilter;
  private complementaryFilter: ComplementaryFilter;

  constructor(config: SensorConfig) {
    this.kalmanFilter = new KalmanFilter({
      processNoise: config.processNoise,
      measurementNoise: config.measurementNoise,
      initialState: config.initialHeading
    });

    this.complementaryFilter = new ComplementaryFilter({
      alpha: config.filterAlpha,
      beta: config.filterBeta
    });
  }

  updateSensorData(type: SensorType, data: SensorReading): void {
    switch (type) {
      case 'magnetometer':
        this.magnetometer = data as MagnetometerReading;
        break;
      case 'gyroscope':
        this.gyroscope = data as GyroscopeReading;
        break;
      case 'accelerometer':
        this.accelerometer = data as AccelerometerReading;
        break;
    }

    this.processFusedHeading();
  }

  private processFusedHeading(): void {
    if (!this.magnetometer || !this.accelerometer) return;

    // Calculate tilt-compensated heading
    const tiltCompensatedHeading = this.calculateTiltCompensation(
      this.magnetometer,
      this.accelerometer
    );

    // Apply sensor fusion
    const fusedHeading = this.kalmanFilter.update(
      tiltCompensatedHeading,
      this.gyroscope?.z || 0
    );

    this.onHeadingUpdate?.(fusedHeading);
  }

  private calculateTiltCompensation(
    mag: MagnetometerReading,
    accel: AccelerometerReading
  ): number {
    // Normalize accelerometer data
    const norm = Math.sqrt(accel.x ** 2 + accel.y ** 2 + accel.z ** 2);
    const ax = accel.x / norm;
    const ay = accel.y / norm;
    const az = accel.z / norm;

    // Calculate roll and pitch
    const roll = Math.atan2(ay, az);
    const pitch = Math.atan2(-ax, Math.sqrt(ay ** 2 + az ** 2));

    // Tilt compensation for magnetometer
    const magX = mag.x * Math.cos(pitch) + mag.z * Math.sin(pitch);
    const magY = mag.x * Math.sin(roll) * Math.sin(pitch) +
                 mag.y * Math.cos(roll) -
                 mag.z * Math.sin(roll) * Math.cos(pitch);

    // Calculate heading
    let heading = Math.atan2(-magY, magX) * (180 / Math.PI);
    if (heading < 0) heading += 360;

    return heading;
  }
}
```

### Device Sensor API Integration

```typescript
// Hook for sensor data management
export const useSensorFusion = (config: SensorConfig) => {
  const [heading, setHeading] = useState<number>(0);
  const [accuracy, setAccuracy] = useState<number>(0);
  const [isCalibrated, setIsCalibrated] = useState<boolean>(false);

  const fusionEngine = useRef<SensorFusionEngine>();

  useEffect(() => {
    fusionEngine.current = new SensorFusionEngine({
      ...config,
      onHeadingUpdate: (newHeading) => {
        setHeading(newHeading);
        setAccuracy(fusionEngine.current?.getAccuracy() || 0);
      }
    });

    return () => {
      fusionEngine.current?.cleanup();
    };
  }, [config]);

  const requestSensorPermissions = async (): Promise<boolean> => {
    try {
      // Request DeviceOrientationEvent permission (iOS 13+)
      if (typeof DeviceOrientationEvent !== 'undefined' &&
          'requestPermission' in DeviceOrientationEvent) {
        const permission = await (DeviceOrientationEvent as any).requestPermission();
        if (permission !== 'granted') return false;
      }

      // Check for sensor availability
      const sensors = await navigator.permissions.query({ name: 'magnetometer' as PermissionName });
      return sensors.state === 'granted';
    } catch (error) {
      console.warn('Sensor permission request failed:', error);
      return false;
    }
  };

  const startSensorReading = async (): Promise<void> => {
    const hasPermission = await requestSensorPermissions();
    if (!hasPermission) {
      throw new Error('Sensor permissions not granted');
    }

    // Start magnetometer
    if ('Magnetometer' in window) {
      const magnetometer = new (window as any).Magnetometer({ frequency: config.updateFrequency });
      magnetometer.addEventListener('reading', () => {
        fusionEngine.current?.updateSensorData('magnetometer', {
          x: magnetometer.x,
          y: magnetometer.y,
          z: magnetometer.z,
          timestamp: Date.now()
        });
      });
      magnetometer.start();
    }

    // Fallback to DeviceOrientationEvent
    else if (typeof DeviceOrientationEvent !== 'undefined') {
      window.addEventListener('deviceorientation', (event) => {
        if (event.alpha !== null) {
          const heading = 360 - event.alpha;
          setHeading(heading);
        }
      });
    }
  };

  return {
    heading,
    accuracy,
    isCalibrated,
    requestSensorPermissions,
    startSensorReading,
    calibrate: () => fusionEngine.current?.startCalibration()
  };
};
```

### Calibration Algorithms

```typescript
class CompassCalibrator {
  private calibrationData: CalibrationPoint[] = [];
  private calibrationMethod: CalibrationMethod;

  constructor(method: CalibrationMethod = 'figure8') {
    this.calibrationMethod = method;
  }

  startCalibration(): void {
    this.calibrationData = [];

    switch (this.calibrationMethod) {
      case 'figure8':
        this.startFigure8Calibration();
        break;
      case 'manual':
        this.startManualCalibration();
        break;
      case 'automatic':
        this.startAutomaticCalibration();
        break;
    }
  }

  private startFigure8Calibration(): void {
    // Figure-8 calibration for magnetometer hard/soft iron correction
    const requiredMotions = 16; // Number of distinct orientations needed
    let collectedPoints = 0;

    const collectCalibrationPoint = (sensorData: MagnetometerReading) => {
      this.calibrationData.push({
        x: sensorData.x,
        y: sensorData.y,
        z: sensorData.z,
        timestamp: Date.now()
      });

      collectedPoints++;

      if (collectedPoints >= requiredMotions) {
        this.processCalibrationData();
      }
    };

    // Provide user guidance
    this.onCalibrationInstruction?.('Hold device flat and move in figure-8 pattern');
  }

  private processCalibrationData(): void {
    if (this.calibrationData.length < 8) {
      throw new Error('Insufficient calibration data');
    }

    // Calculate hard iron offset (bias)
    const hardIronOffset = this.calculateHardIronOffset();

    // Calculate soft iron matrix (scale and rotation)
    const softIronMatrix = this.calculateSoftIronMatrix();

    // Validate calibration quality
    const quality = this.validateCalibration(hardIronOffset, softIronMatrix);

    if (quality.score < 0.8) {
      this.onCalibrationFailed?.('Calibration quality too low, please try again');
      return;
    }

    // Save calibration parameters
    this.saveCalibrationData({
      hardIronOffset,
      softIronMatrix,
      quality,
      method: this.calibrationMethod,
      timestamp: Date.now()
    });

    this.onCalibrationComplete?.(quality);
  }

  private calculateHardIronOffset(): Vector3D {
    // Calculate the center point of the ellipsoid formed by calibration data
    const sumX = this.calibrationData.reduce((sum, point) => sum + point.x, 0);
    const sumY = this.calibrationData.reduce((sum, point) => sum + point.y, 0);
    const sumZ = this.calibrationData.reduce((sum, point) => sum + point.z, 0);

    const count = this.calibrationData.length;

    return {
      x: sumX / count,
      y: sumY / count,
      z: sumZ / count
    };
  }

  private calculateSoftIronMatrix(): Matrix3x3 {
    // Simplified ellipsoid fitting for soft iron correction
    // In production, use more sophisticated algorithms like least squares
    const correctedData = this.calibrationData.map(point => ({
      x: point.x - this.hardIronOffset.x,
      y: point.y - this.hardIronOffset.y,
      z: point.z - this.hardIronOffset.z
    }));

    // Calculate scale factors for each axis
    const xScale = this.calculateAxisScale(correctedData.map(p => p.x));
    const yScale = this.calculateAxisScale(correctedData.map(p => p.y));
    const zScale = this.calculateAxisScale(correctedData.map(p => p.z));

    return [
      [xScale, 0, 0],
      [0, yScale, 0],
      [0, 0, zScale]
    ];
  }
}
```

## 6. Security Design

### Authentication & Authorization

```typescript
// Role-based access control
interface CompassPermissions {
  canMeasure: boolean;
  canSave: boolean;
  canExport: boolean;
  canAccessHistory: boolean;
  canUseProfessionalFeatures: boolean;
  maxMeasurementsPerDay: number;
  canAccessAIAnalysis: boolean;
}

const getCompassPermissions = (userRole: UserRole): CompassPermissions => {
  switch (userRole) {
    case 'guest':
      return {
        canMeasure: true,
        canSave: false,
        canExport: false,
        canAccessHistory: false,
        canUseProfessionalFeatures: false,
        maxMeasurementsPerDay: 10,
        canAccessAIAnalysis: true
      };

    case 'user':
      return {
        canMeasure: true,
        canSave: true,
        canExport: true,
        canAccessHistory: true,
        canUseProfessionalFeatures: false,
        maxMeasurementsPerDay: 100,
        canAccessAIAnalysis: true
      };

    case 'premium':
      return {
        canMeasure: true,
        canSave: true,
        canExport: true,
        canAccessHistory: true,
        canUseProfessionalFeatures: true,
        maxMeasurementsPerDay: 1000,
        canAccessAIAnalysis: true
      };

    case 'professional':
      return {
        canMeasure: true,
        canSave: true,
        canExport: true,
        canAccessHistory: true,
        canUseProfessionalFeatures: true,
        maxMeasurementsPerDay: -1, // Unlimited
        canAccessAIAnalysis: true
      };
  }
};
```

### Data Encryption

```typescript
// Location data encryption
class LocationEncryption {
  private static readonly ALGORITHM = 'AES-256-GCM';
  private static readonly KEY_LENGTH = 32;
  private static readonly IV_LENGTH = 16;

  static async encrypt(
    locationData: { latitude: number; longitude: number },
    userKey: string
  ): Promise<EncryptedLocation> {
    const data = JSON.stringify(locationData);
    const key = await this.deriveKey(userKey);
    const iv = crypto.getRandomValues(new Uint8Array(this.IV_LENGTH));

    const algorithm = { name: 'AES-GCM', iv };
    const encodedData = new TextEncoder().encode(data);

    const encryptedData = await crypto.subtle.encrypt(algorithm, key, encodedData);

    return {
      encryptedData: Array.from(new Uint8Array(encryptedData)),
      iv: Array.from(iv),
      algorithm: this.ALGORITHM
    };
  }

  static async decrypt(
    encryptedLocation: EncryptedLocation,
    userKey: string
  ): Promise<{ latitude: number; longitude: number }> {
    const key = await this.deriveKey(userKey);
    const iv = new Uint8Array(encryptedLocation.iv);
    const encryptedData = new Uint8Array(encryptedLocation.encryptedData);

    const algorithm = { name: 'AES-GCM', iv };
    const decryptedData = await crypto.subtle.decrypt(algorithm, key, encryptedData);

    const decodedData = new TextDecoder().decode(decryptedData);
    return JSON.parse(decodedData);
  }

  private static async deriveKey(userKey: string): Promise<CryptoKey> {
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      new TextEncoder().encode(userKey),
      'PBKDF2',
      false,
      ['deriveKey']
    );

    return crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: new TextEncoder().encode('compass-salt'),
        iterations: 100000,
        hash: 'SHA-256'
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }
}
```

### Input Validation

```typescript
// Zod schemas for API validation
import { z } from 'zod';

const CompassMeasurementSchema = z.object({
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  magneticHeading: z.number().min(0).max(360),
  trueHeading: z.number().min(0).max(360),
  accuracy: z.number().min(0).max(100),
  timestamp: z.string().datetime(),
  sessionId: z.string().uuid(),
  deviceInfo: z.object({
    userAgent: z.string(),
    platform: z.string(),
    sensors: z.array(z.string())
  }).optional()
});

// API route validation
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const validatedData = CompassMeasurementSchema.parse(body);

    // Check user permissions
    const user = await getCurrentUser();
    const permissions = getCompassPermissions(user?.role || 'guest');

    if (!permissions.canMeasure) {
      return NextResponse.json({ error: 'Insufficient permissions' }, { status: 403 });
    }

    // Rate limiting check
    const dailyCount = await getDailyMeasurementCount(user?.id);
    if (permissions.maxMeasurementsPerDay > 0 &&
        dailyCount >= permissions.maxMeasurementsPerDay) {
      return NextResponse.json({ error: 'Daily limit exceeded' }, { status: 429 });
    }

    // Process measurement
    const measurement = await saveMeasurement(validatedData, user);
    return NextResponse.json({ success: true, measurement });

  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: 'Invalid input', details: error.errors }, { status: 400 });
    }

    console.error('Compass API error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
```

### Rate Limiting

```typescript
// Redis-based rate limiting
class RateLimiter {
  private redis: RedisClient;

  constructor(redis: RedisClient) {
    this.redis = redis;
  }

  async checkLimit(
    identifier: string,
    windowMs: number,
    maxRequests: number
  ): Promise<{ allowed: boolean; remaining: number; resetTime: number }> {
    const key = `rate_limit:${identifier}`;
    const now = Date.now();
    const windowStart = now - windowMs;

    // Remove old entries
    await this.redis.zremrangebyscore(key, 0, windowStart);

    // Count current requests
    const currentCount = await this.redis.zcard(key);

    if (currentCount >= maxRequests) {
      const oldestEntry = await this.redis.zrange(key, 0, 0, 'WITHSCORES');
      const resetTime = oldestEntry.length > 0 ?
        parseInt(oldestEntry[1]) + windowMs :
        now + windowMs;

      return {
        allowed: false,
        remaining: 0,
        resetTime
      };
    }

    // Add current request
    await this.redis.zadd(key, now, `${now}-${Math.random()}`);
    await this.redis.expire(key, Math.ceil(windowMs / 1000));

    return {
      allowed: true,
      remaining: maxRequests - currentCount - 1,
      resetTime: now + windowMs
    };
  }
}

// Usage in API routes
const rateLimiter = new RateLimiter(redisClient);

export async function POST(request: Request) {
  const clientIP = getClientIP(request);
  const { allowed, remaining, resetTime } = await rateLimiter.checkLimit(
    clientIP,
    60000, // 1 minute window
    10     // 10 requests per minute
  );

  if (!allowed) {
    return NextResponse.json(
      { error: 'Rate limit exceeded' },
      {
        status: 429,
        headers: {
          'X-RateLimit-Remaining': '0',
          'X-RateLimit-Reset': resetTime.toString()
        }
      }
    );
  }

  // Process request...
}
```

## 7. Performance Optimization

### Frontend Performance

```typescript
// React.memo for compass components
const CompassLayer = React.memo<CompassLayerProps>(({ layer, rotation, size }) => {
  const layerElements = useMemo(() => {
    return layer.data.map((item, index) => {
      const angle = (360 / layer.data.length) * index + layer.startAngle;
      return (
        <CompassElement
          key={`${layer.id}-${index}`}
          text={item}
          angle={angle}
          radius={size * 0.8}
          style={layer.style}
        />
      );
    });
  }, [layer.data, layer.startAngle, layer.id, size, layer.style]);

  return (
    <g transform={`rotate(${rotation})`}>
      {layerElements}
    </g>
  );
});

// Debounced sensor updates
const useDebouncedSensor = (sensorData: SensorReading[], delay: number = 16) => {
  const [debouncedData, setDebouncedData] = useState(sensorData);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedData(sensorData);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [sensorData, delay]);

  return debouncedData;
};

// Web Worker for heavy calculations
// compass-worker.ts
self.onmessage = function(e) {
  const { type, data } = e.data;

  switch (type) {
    case 'CALCULATE_FLYING_STARS':
      const result = calculateFlyingStars(data);
      self.postMessage({ type: 'FLYING_STARS_RESULT', result });
      break;

    case 'PROCESS_SENSOR_FUSION':
      const fusedHeading = processSensorFusion(data);
      self.postMessage({ type: 'SENSOR_FUSION_RESULT', heading: fusedHeading });
      break;
  }
};

// Hook for Web Worker
const useCompassWorker = () => {
  const workerRef = useRef<Worker>();

  useEffect(() => {
    workerRef.current = new Worker(new URL('./compass-worker.ts', import.meta.url));

    return () => {
      workerRef.current?.terminate();
    };
  }, []);

  const calculateFlyingStars = useCallback((data: FlyingStarsInput) => {
    return new Promise((resolve) => {
      if (!workerRef.current) return;

      const handleMessage = (e: MessageEvent) => {
        if (e.data.type === 'FLYING_STARS_RESULT') {
          workerRef.current?.removeEventListener('message', handleMessage);
          resolve(e.data.result);
        }
      };

      workerRef.current.addEventListener('message', handleMessage);
      workerRef.current.postMessage({ type: 'CALCULATE_FLYING_STARS', data });
    });
  }, []);

  return { calculateFlyingStars };
};
```

### Canvas vs SVG Performance

```typescript
// Adaptive renderer based on device capability
const CompassRenderer = ({ layers, size, rotation, performance }: CompassRendererProps) => {
  const renderingStrategy = useMemo(() => {
    const devicePixelRatio = window.devicePixelRatio || 1;
    const isHighDPI = devicePixelRatio > 1.5;
    const layerCount = layers.length;
    const elementCount = layers.reduce((sum, layer) => sum + layer.data.length, 0);

    // Use Canvas for:
    // - High element count (>100 elements)
    // - Low-end devices
    // - High-DPI displays with many elements
    if (elementCount > 100 || performance === 'low' || (isHighDPI && elementCount > 50)) {
      return 'canvas';
    }

    // Use SVG for:
    // - Interactive features needed
    // - Accessibility requirements
    // - Print quality output
    return 'svg';
  }, [layers, performance]);

  if (renderingStrategy === 'canvas') {
    return <CanvasCompass layers={layers} size={size} rotation={rotation} />;
  }

  return <SVGCompass layers={layers} size={size} rotation={rotation} />;
};

// Canvas implementation with optimal redraw
const CanvasCompass = ({ layers, size, rotation }: CanvasCompassProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  const draw = useCallback((ctx: CanvasRenderingContext2D, timestamp: number) => {
    const canvas = ctx.canvas;
    const dpr = window.devicePixelRatio || 1;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Save context state
    ctx.save();

    // Apply rotation
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.translate(-canvas.width / 2, -canvas.height / 2);

    // Draw layers
    layers.forEach(layer => {
      drawLayer(ctx, layer, size, dpr);
    });

    // Restore context state
    ctx.restore();
  }, [layers, size, rotation]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const animate = (timestamp: number) => {
      draw(ctx, timestamp);
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [draw]);

  return (
    <canvas
      ref={canvasRef}
      width={size * (window.devicePixelRatio || 1)}
      height={size * (window.devicePixelRatio || 1)}
      style={{ width: size, height: size }}
    />
  );
};
```

### Backend Caching

```typescript
// Multi-layer caching strategy
interface CacheConfig {
  memory: {
    ttl: number;
    maxSize: number;
  };
  redis: {
    ttl: number;
    keyPrefix: string;
  };
  database: {
    cacheQueries: boolean;
    preparedStatements: boolean;
  };
}

class CompassCacheManager {
  private memoryCache: Map<string, CacheEntry> = new Map();
  private redis: RedisClient;
  private config: CacheConfig;

  constructor(redis: RedisClient, config: CacheConfig) {
    this.redis = redis;
    this.config = config;

    // Cleanup memory cache periodically
    setInterval(() => this.cleanupMemoryCache(), 60000);
  }

  async get<T>(key: string): Promise<T | null> {
    // Try memory cache first
    const memoryEntry = this.memoryCache.get(key);
    if (memoryEntry && memoryEntry.expiresAt > Date.now()) {
      return memoryEntry.value as T;
    }

    // Try Redis cache
    const redisKey = `${this.config.redis.keyPrefix}:${key}`;
    const redisValue = await this.redis.get(redisKey);
    if (redisValue) {
      const parsed = JSON.parse(redisValue) as T;

      // Store in memory cache for faster access
      this.setMemoryCache(key, parsed);

      return parsed;
    }

    return null;
  }

  async set<T>(key: string, value: T): Promise<void> {
    // Store in memory cache
    this.setMemoryCache(key, value);

    // Store in Redis
    const redisKey = `${this.config.redis.keyPrefix}:${key}`;
    await this.redis.setex(
      redisKey,
      this.config.redis.ttl,
      JSON.stringify(value)
    );
  }

  private setMemoryCache<T>(key: string, value: T): void {
    // Remove oldest entries if cache is full
    if (this.memoryCache.size >= this.config.memory.maxSize) {
      const oldestKey = this.memoryCache.keys().next().value;
      if (oldestKey) {
        this.memoryCache.delete(oldestKey);
      }
    }

    this.memoryCache.set(key, {
      value,
      expiresAt: Date.now() + this.config.memory.ttl
    });
  }

  private cleanupMemoryCache(): void {
    const now = Date.now();
    for (const [key, entry] of this.memoryCache.entries()) {
      if (entry.expiresAt <= now) {
        this.memoryCache.delete(key);
      }
    }
  }
}

// Usage in API routes
const cacheManager = new CompassCacheManager(redisClient, {
  memory: { ttl: 60000, maxSize: 1000 },
  redis: { ttl: 3600, keyPrefix: 'compass' },
  database: { cacheQueries: true, preparedStatements: true }
});

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const lat = searchParams.get('lat');
  const lng = searchParams.get('lng');

  const cacheKey = `declination:${lat}:${lng}`;

  // Try cache first
  let declination = await cacheManager.get<number>(cacheKey);

  if (declination === null) {
    // Calculate magnetic declination
    declination = await calculateMagneticDeclination(
      parseFloat(lat!),
      parseFloat(lng!)
    );

    // Cache the result
    await cacheManager.set(cacheKey, declination);
  }

  return NextResponse.json({ declination });
}
```

## 8. Testing Strategy

### Unit Testing

```typescript
// Jest configuration for compass components
// jest.config.js
module.exports = {
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: ['<rootDir>/src/test/setup.ts'],
  moduleNameMapping: {
    '^@/(.*)$': '<rootDir>/src/$1'
  },
  collectCoverageFrom: [
    'src/components/compass/**/*.{ts,tsx}',
    'src/lib/compass/**/*.{ts,tsx}',
    '!src/**/*.d.ts',
    '!src/**/*.stories.{ts,tsx}'
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80
    }
  }
};

// Test setup
// src/test/setup.ts
import '@testing-library/jest-dom';

// Mock sensor APIs
Object.defineProperty(window, 'DeviceOrientationEvent', {
  value: class MockDeviceOrientationEvent extends Event {
    alpha = 0;
    beta = 0;
    gamma = 0;
    static requestPermission = jest.fn().mockResolvedValue('granted');
  }
});

Object.defineProperty(navigator, 'permissions', {
  value: {
    query: jest.fn().mockResolvedValue({ state: 'granted' })
  }
});

// Component tests
describe('FengShuiCompass', () => {
  const mockLayers: CompassLayer[] = [
    {
      id: 'test-layer',
      name: '测试层',
      data: ['北', '东', '南', '西'],
      startAngle: 0,
      fontSize: 16,
      textColor: 'black',
      vertical: false,
      togetherStyle: 'empty',
      shape: 'circle',
      visible: true
    }
  ];

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders compass with correct layers', () => {
    render(<FengShuiCompass layers={mockLayers} size={300} rotation={0} />);

    expect(screen.getByLabelText('Feng Shui Compass')).toBeInTheDocument();
    expect(screen.getByText('北')).toBeInTheDocument();
    expect(screen.getByText('东')).toBeInTheDocument();
  });

  it('applies rotation correctly', () => {
    const { rerender } = render(
      <FengShuiCompass layers={mockLayers} size={300} rotation={0} />
    );

    const compass = screen.getByLabelText('Feng Shui Compass');
    expect(compass).toHaveStyle('transform: rotate(0deg)');

    rerender(<FengShuiCompass layers={mockLayers} size={300} rotation={90} />);
    expect(compass).toHaveStyle('transform: rotate(90deg)');
  });

  it('handles sensor permission requests', async () => {
    const mockRequestPermission = jest.fn().mockResolvedValue('granted');
    (DeviceOrientationEvent as any).requestPermission = mockRequestPermission;

    render(<FengShuiCompass layers={mockLayers} size={300} rotation={0} />);

    const enableSensorButton = screen.getByText('Enable Sensor');
    fireEvent.click(enableSensorButton);

    await waitFor(() => {
      expect(mockRequestPermission).toHaveBeenCalled();
    });
  });
});

// Algorithm tests
describe('Sensor Fusion', () => {
  let fusionEngine: SensorFusionEngine;

  beforeEach(() => {
    fusionEngine = new SensorFusionEngine({
      processNoise: 0.1,
      measurementNoise: 0.5,
      initialHeading: 0
    });
  });

  it('processes magnetometer data correctly', () => {
    const mockCallback = jest.fn();
    fusionEngine.onHeadingUpdate = mockCallback;

    fusionEngine.updateSensorData('magnetometer', {
      x: 0.5,
      y: 0.3,
      z: -0.8,
      timestamp: Date.now()
    });

    fusionEngine.updateSensorData('accelerometer', {
      x: 0,
      y: 0,
      z: 9.81,
      timestamp: Date.now()
    });

    expect(mockCallback).toHaveBeenCalledWith(expect.any(Number));
  });

  it('calculates tilt compensation accurately', () => {
    const magnetometer = { x: 0.5, y: 0.3, z: -0.8, timestamp: Date.now() };
    const accelerometer = { x: 0, y: 0, z: 9.81, timestamp: Date.now() };

    const heading = fusionEngine.calculateTiltCompensation(magnetometer, accelerometer);

    expect(heading).toBeGreaterThanOrEqual(0);
    expect(heading).toBeLessThan(360);
  });
});

// Error handling tests
describe('Error Handling', () => {
  it('handles sensor unavailability gracefully', async () => {
    // Mock sensor not available
    Object.defineProperty(navigator, 'permissions', {
      value: {
        query: jest.fn().mockRejectedValue(new Error('Sensor not available'))
      }
    });

    const { result } = renderHook(() => useSensorFusion({
      enableMagnetometer: true,
      updateFrequency: 60
    }));

    await act(async () => {
      try {
        await result.current.startSensorReading();
      } catch (error) {
        expect(error.message).toContain('Sensor permissions not granted');
      }
    });
  });
});
```

### Integration Testing

```typescript
// API integration tests
describe('Compass API Integration', () => {
  beforeEach(async () => {
    await setupTestDatabase();
  });

  afterEach(async () => {
    await cleanupTestDatabase();
  });

  describe('POST /api/compass/measurements', () => {
    it('saves valid compass measurement', async () => {
      const measurement = {
        latitude: 40.7128,
        longitude: -74.0060,
        magneticHeading: 45.5,
        trueHeading: 47.3,
        accuracy: 0.8,
        timestamp: new Date().toISOString(),
        sessionId: uuid()
      };

      const response = await POST(
        new Request('http://localhost/api/compass/measurements', {
          method: 'POST',
          body: JSON.stringify(measurement),
          headers: { 'Content-Type': 'application/json' }
        })
      );

      expect(response.status).toBe(200);

      const result = await response.json();
      expect(result.success).toBe(true);
      expect(result.measurement.id).toBeDefined();
    });

    it('rejects invalid coordinates', async () => {
      const invalidMeasurement = {
        latitude: 91, // Invalid latitude
        longitude: -74.0060,
        magneticHeading: 45.5,
        trueHeading: 47.3,
        timestamp: new Date().toISOString(),
        sessionId: uuid()
      };

      const response = await POST(
        new Request('http://localhost/api/compass/measurements', {
          method: 'POST',
          body: JSON.stringify(invalidMeasurement),
          headers: { 'Content-Type': 'application/json' }
        })
      );

      expect(response.status).toBe(400);

      const result = await response.json();
      expect(result.error).toBe('Invalid input');
    });

    it('enforces rate limiting', async () => {
      const measurement = {
        latitude: 40.7128,
        longitude: -74.0060,
        magneticHeading: 45.5,
        trueHeading: 47.3,
        timestamp: new Date().toISOString(),
        sessionId: uuid()
      };

      // Make multiple requests rapidly
      const requests = Array.from({ length: 15 }, () =>
        POST(new Request('http://localhost/api/compass/measurements', {
          method: 'POST',
          body: JSON.stringify(measurement),
          headers: { 'Content-Type': 'application/json' }
        }))
      );

      const responses = await Promise.all(requests);

      // Some requests should be rate limited
      const rateLimited = responses.filter(r => r.status === 429);
      expect(rateLimited.length).toBeGreaterThan(0);
    });
  });

  describe('Database Operations', () => {
    it('stores and retrieves measurements correctly', async () => {
      const measurement: CompassMeasurement = {
        id: uuid(),
        sessionId: uuid(),
        timestamp: new Date(),
        latitude: 40.7128,
        longitude: -74.0060,
        magneticHeading: 45.5,
        trueHeading: 47.3,
        accuracy: 0.8,
        deviceInfo: {
          userAgent: 'test-agent',
          platform: 'test-platform',
          sensors: ['magnetometer', 'accelerometer']
        }
      };

      // Save measurement
      await saveMeasurement(measurement);

      // Retrieve measurement
      const retrieved = await getMeasurement(measurement.id);

      expect(retrieved).toBeDefined();
      expect(retrieved.magneticHeading).toBe(45.5);
      expect(retrieved.trueHeading).toBe(47.3);
    });

    it('encrypts location data properly', async () => {
      const measurement = {
        latitude: 40.7128,
        longitude: -74.0060,
        // ... other fields
      };

      const userKey = 'test-encryption-key';

      // Save with encryption
      const saved = await saveMeasurementWithEncryption(measurement, userKey);

      // Verify raw data is encrypted
      const raw = await getRawMeasurementFromDB(saved.id);
      expect(raw.latitude).not.toBe(40.7128);
      expect(raw.longitude).not.toBe(-74.0060);

      // Verify decryption works
      const decrypted = await getMeasurementWithDecryption(saved.id, userKey);
      expect(decrypted.latitude).toBe(40.7128);
      expect(decrypted.longitude).toBe(-74.0060);
    });
  });
});
```

### End-to-End Testing

```typescript
// Playwright E2E tests
import { test, expect } from '@playwright/test';

test.describe('Compass Integration E2E', () => {
  test.beforeEach(async ({ page }) => {
    // Grant permissions for location and sensors
    await page.context().grantPermissions(['geolocation']);

    // Mock geolocation
    await page.addInitScript(() => {
      const mockGeolocation = {
        getCurrentPosition: (success: PositionCallback) => {
          success({
            coords: {
              latitude: 40.7128,
              longitude: -74.0060,
              accuracy: 10,
              altitude: null,
              altitudeAccuracy: null,
              heading: null,
              speed: null
            },
            timestamp: Date.now()
          });
        },
        watchPosition: (success: PositionCallback) => {
          success({
            coords: {
              latitude: 40.7128,
              longitude: -74.0060,
              accuracy: 10,
              altitude: null,
              altitudeAccuracy: null,
              heading: null,
              speed: null
            },
            timestamp: Date.now()
          });
          return 1;
        },
        clearWatch: () => {}
      };

      Object.defineProperty(navigator, 'geolocation', {
        value: mockGeolocation
      });
    });

    await page.goto('/compass');
  });

  test('user can access compass page', async ({ page }) => {
    await expect(page.locator('[data-testid="feng-shui-compass"]')).toBeVisible();
    await expect(page.locator('text=风水罗盘')).toBeVisible();
  });

  test('compass shows proper layers', async ({ page }) => {
    // Wait for compass to load
    await page.waitForLoadState('networkidle');

    // Check for 24 mountains layer
    await expect(page.locator('text=子')).toBeVisible();
    await expect(page.locator('text=午')).toBeVisible();

    // Check for bagua layer
    await expect(page.locator('text=坎')).toBeVisible();
    await expect(page.locator('text=离')).toBeVisible();
  });

  test('user can enable sensor mode', async ({ page }) => {
    // Mock device orientation
    await page.addInitScript(() => {
      Object.defineProperty(window, 'DeviceOrientationEvent', {
        value: class extends Event {
          alpha = 45;
          beta = 0;
          gamma = 0;
          static requestPermission = () => Promise.resolve('granted');
        }
      });
    });

    await page.click('[data-testid="enable-sensor-button"]');

    // Should show permission dialog
    await expect(page.locator('text=Enable device sensors')).toBeVisible();

    await page.click('[data-testid="grant-permission-button"]');

    // Compass should rotate to match device orientation
    await page.waitForTimeout(1000);

    const compass = page.locator('[data-testid="compass-container"]');
    const transform = await compass.getAttribute('style');
    expect(transform).toContain('rotate');
  });

  test('user can save measurements', async ({ page }) => {
    // Login first
    await page.goto('/login');
    await page.fill('[data-testid="email-input"]', 'test@example.com');
    await page.fill('[data-testid="password-input"]', 'password123');
    await page.click('[data-testid="login-button"]');

    await page.goto('/compass');

    // Take a measurement
    await page.click('[data-testid="take-measurement-button"]');

    // Add notes
    await page.fill('[data-testid="measurement-notes"]', 'Test measurement');

    // Save measurement
    await page.click('[data-testid="save-measurement-button"]');

    // Should show success message
    await expect(page.locator('text=Measurement saved successfully')).toBeVisible();

    // Should appear in measurement history
    await page.click('[data-testid="view-history-button"]');
    await expect(page.locator('text=Test measurement')).toBeVisible();
  });

  test('guest user sees usage limitations', async ({ page }) => {
    // Should show guest limitations
    await expect(page.locator('text=Guest mode')).toBeVisible();
    await expect(page.locator('text=Limited measurements')).toBeVisible();

    // Take multiple measurements
    for (let i = 0; i < 12; i++) {
      await page.click('[data-testid="take-measurement-button"]');
      await page.waitForTimeout(100);
    }

    // Should show limit reached message
    await expect(page.locator('text=Daily limit reached')).toBeVisible();
    await expect(page.locator('text=Sign up for unlimited')).toBeVisible();
  });

  test('compass analysis integration works', async ({ page }) => {
    // Mock AI analysis response
    await page.route('**/api/ai/analyze', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          analysis: {
            flyingStars: {
              period: 9,
              sector: '坎',
              energy: 'favorable',
              recommendations: ['Place water element in north sector']
            },
            confidence: 0.87
          }
        })
      });
    });

    // Take measurement
    await page.click('[data-testid="take-measurement-button"]');

    // Request AI analysis
    await page.click('[data-testid="analyze-button"]');

    // Should show loading state
    await expect(page.locator('[data-testid="analysis-loading"]')).toBeVisible();

    // Should show analysis results
    await expect(page.locator('text=Flying Stars Analysis')).toBeVisible();
    await expect(page.locator('text=favorable')).toBeVisible();
    await expect(page.locator('text=water element')).toBeVisible();

    // Should show confidence score
    await expect(page.locator('text=87% confidence')).toBeVisible();
  });

  test('responsive design works on mobile', async ({ page }) => {
    // Set mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });

    // Compass should be appropriately sized
    const compass = page.locator('[data-testid="feng-shui-compass"]');
    const boundingBox = await compass.boundingBox();

    expect(boundingBox?.width).toBeLessThanOrEqual(375);
    expect(boundingBox?.height).toBeLessThanOrEqual(375);

    // Touch interactions should work
    await page.tap('[data-testid="compass-container"]');

    // Mobile-specific UI elements should be visible
    await expect(page.locator('[data-testid="mobile-controls"]')).toBeVisible();
  });
});

// Performance tests
test.describe('Performance Tests', () => {
  test('compass loads within performance budget', async ({ page }) => {
    const startTime = Date.now();

    await page.goto('/compass');
    await page.waitForLoadState('networkidle');

    const loadTime = Date.now() - startTime;
    expect(loadTime).toBeLessThan(3000); // 3 second budget

    // Check Lighthouse metrics
    const metrics = await page.evaluate(() => {
      return new Promise(resolve => {
        new PerformanceObserver(list => {
          const entries = list.getEntries();
          const fcp = entries.find(entry => entry.name === 'first-contentful-paint');
          const lcp = entries.find(entry => entry.name === 'largest-contentful-paint');

          resolve({
            fcp: fcp?.startTime || 0,
            lcp: lcp?.startTime || 0
          });
        }).observe({ entryTypes: ['paint', 'largest-contentful-paint'] });
      });
    });

    expect(metrics.fcp).toBeLessThan(1500); // FCP < 1.5s
    expect(metrics.lcp).toBeLessThan(2500); // LCP < 2.5s
  });

  test('compass rotation is smooth', async ({ page }) => {
    await page.goto('/compass');

    // Monitor frame rate during rotation
    const frameRates: number[] = [];

    await page.evaluate(() => {
      let lastTime = performance.now();
      const measureFrameRate = (currentTime: number) => {
        const deltaTime = currentTime - lastTime;
        const fps = 1000 / deltaTime;
        (window as any).frameRates.push(fps);
        lastTime = currentTime;

        if ((window as any).frameRates.length < 60) {
          requestAnimationFrame(measureFrameRate);
        }
      };

      (window as any).frameRates = [];
      requestAnimationFrame(measureFrameRate);
    });

    // Simulate compass rotation
    await page.mouse.move(200, 200);
    await page.mouse.down();

    for (let i = 0; i < 10; i++) {
      await page.mouse.move(200 + i * 10, 200);
      await page.waitForTimeout(16); // ~60fps
    }

    await page.mouse.up();

    // Check frame rates
    const frameRates = await page.evaluate(() => (window as any).frameRates);
    const averageFPS = frameRates.reduce((sum: number, fps: number) => sum + fps, 0) / frameRates.length;

    expect(averageFPS).toBeGreaterThan(45); // Minimum 45 FPS
  });
});
```

## 9. Deployment Architecture

### CI/CD Pipeline

```yaml
# .github/workflows/compass-integration.yml
name: Compass Integration CI/CD

on:
  push:
    branches: [main, develop]
    paths:
      - 'src/components/compass/**'
      - 'src/lib/compass/**'
      - 'src/app/api/compass/**'
  pull_request:
    branches: [main]
    paths:
      - 'src/components/compass/**'
      - 'src/lib/compass/**'
      - 'src/app/api/compass/**'

jobs:
  quality-checks:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Lint
        run: npm run lint -- --max-warnings 0

      - name: Type check
        run: npm run type-check

      - name: Unit tests
        run: npm run test -- --coverage --watchAll=false
        env:
          CI: true

      - name: Upload coverage
        uses: codecov/codecov-action@v3
        with:
          file: ./coverage/lcov.info
          fail_ci_if_error: true

  integration-tests:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:15
        env:
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: qiflow_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5

      redis:
        image: redis:7
        options: >-
          --health-cmd "redis-cli ping"
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5

    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Setup test database
        run: |
          npm run db:setup:test
          npm run db:migrate:test
        env:
          DATABASE_URL: postgresql://postgres:postgres@localhost:5432/qiflow_test
          REDIS_URL: redis://localhost:6379

      - name: Integration tests
        run: npm run test:integration
        env:
          DATABASE_URL: postgresql://postgres:postgres@localhost:5432/qiflow_test
          REDIS_URL: redis://localhost:6379
          NEXT_PUBLIC_SUPABASE_URL: ${{ secrets.SUPABASE_TEST_URL }}
          SUPABASE_SERVICE_ROLE_KEY: ${{ secrets.SUPABASE_TEST_SERVICE_KEY }}

  e2e-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Install Playwright
        run: npx playwright install --with-deps chromium

      - name: Build application
        run: npm run build
        env:
          NEXT_PUBLIC_SUPABASE_URL: ${{ secrets.SUPABASE_TEST_URL }}
          NEXT_PUBLIC_SUPABASE_ANON_KEY: ${{ secrets.SUPABASE_TEST_ANON_KEY }}

      - name: Run E2E tests
        run: npm run test:e2e
        env:
          BASE_URL: http://localhost:3000
          TEST_USER_EMAIL: ${{ secrets.TEST_USER_EMAIL }}
          TEST_USER_PASSWORD: ${{ secrets.TEST_USER_PASSWORD }}

      - name: Upload test results
        uses: actions/upload-artifact@v3
        if: failure()
        with:
          name: playwright-report
          path: playwright-report/

  security-scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Run Trivy vulnerability scanner
        uses: aquasecurity/trivy-action@master
        with:
          scan-type: 'fs'
          scan-ref: '.'
          format: 'sarif'
          output: 'trivy-results.sarif'

      - name: Upload Trivy scan results
        uses: github/codeql-action/upload-sarif@v2
        with:
          sarif_file: 'trivy-results.sarif'

  performance-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Build application
        run: npm run build

      - name: Start application
        run: npm start &
        env:
          PORT: 3000

      - name: Wait for application
        run: npx wait-on http://localhost:3000

      - name: Run Lighthouse CI
        run: npm run lighthouse:ci
        env:
          LHCI_GITHUB_APP_TOKEN: ${{ secrets.LHCI_GITHUB_APP_TOKEN }}

  deploy-staging:
    needs: [quality-checks, integration-tests, e2e-tests, security-scan]
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/develop'

    steps:
      - uses: actions/checkout@v4

      - name: Deploy to Vercel Staging
        uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          github-token: ${{ secrets.GITHUB_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
          scope: ${{ secrets.VERCEL_ORG_ID }}
          alias-domains: staging.qiflow.ai

  deploy-production:
    needs: [quality-checks, integration-tests, e2e-tests, security-scan, performance-tests]
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'

    steps:
      - uses: actions/checkout@v4

      - name: Deploy to Vercel Production
        uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          github-token: ${{ secrets.GITHUB_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
          vercel-args: '--prod'
          scope: ${{ secrets.VERCEL_ORG_ID }}
```

### Environment Configuration

```typescript
// Environment-specific configurations
interface EnvironmentConfig {
  database: {
    url: string;
    poolSize: number;
    ssl: boolean;
  };
  redis: {
    url: string;
    cluster: boolean;
  };
  ai: {
    providers: string[];
    fallback: boolean;
  };
  compass: {
    maxMeasurementsPerDay: Record<string, number>;
    sensorUpdateFrequency: number;
    cacheEnabled: boolean;
  };
  monitoring: {
    enableMetrics: boolean;
    enableTracing: boolean;
    errorReporting: boolean;
  };
}

const configs: Record<string, EnvironmentConfig> = {
  development: {
    database: {
      url: process.env.DATABASE_URL!,
      poolSize: 5,
      ssl: false
    },
    redis: {
      url: process.env.REDIS_URL || 'redis://localhost:6379',
      cluster: false
    },
    ai: {
      providers: ['openai'],
      fallback: false
    },
    compass: {
      maxMeasurementsPerDay: {
        guest: 10,
        user: 100,
        premium: 1000,
        professional: -1
      },
      sensorUpdateFrequency: 30, // Hz
      cacheEnabled: true
    },
    monitoring: {
      enableMetrics: false,
      enableTracing: false,
      errorReporting: false
    }
  },

  staging: {
    database: {
      url: process.env.DATABASE_URL!,
      poolSize: 10,
      ssl: true
    },
    redis: {
      url: process.env.REDIS_URL!,
      cluster: false
    },
    ai: {
      providers: ['openai', 'anthropic'],
      fallback: true
    },
    compass: {
      maxMeasurementsPerDay: {
        guest: 5,
        user: 50,
        premium: 500,
        professional: -1
      },
      sensorUpdateFrequency: 30,
      cacheEnabled: true
    },
    monitoring: {
      enableMetrics: true,
      enableTracing: true,
      errorReporting: true
    }
  },

  production: {
    database: {
      url: process.env.DATABASE_URL!,
      poolSize: 20,
      ssl: true
    },
    redis: {
      url: process.env.REDIS_URL!,
      cluster: true
    },
    ai: {
      providers: ['openai', 'anthropic', 'gemini'],
      fallback: true
    },
    compass: {
      maxMeasurementsPerDay: {
        guest: 10,
        user: 100,
        premium: 1000,
        professional: -1
      },
      sensorUpdateFrequency: 60,
      cacheEnabled: true
    },
    monitoring: {
      enableMetrics: true,
      enableTracing: true,
      errorReporting: true
    }
  }
};

export const getConfig = (): EnvironmentConfig => {
  const env = process.env.NODE_ENV || 'development';
  return configs[env] || configs.development;
};
```

### Monitoring & Observability

```typescript
// Prometheus metrics
import prometheus from 'prom-client';

// Custom metrics for compass functionality
const compassMetrics = {
  measurementCounter: new prometheus.Counter({
    name: 'compass_measurements_total',
    help: 'Total number of compass measurements taken',
    labelNames: ['user_type', 'sensor_type', 'status']
  }),

  measurementAccuracy: new prometheus.Histogram({
    name: 'compass_measurement_accuracy',
    help: 'Accuracy of compass measurements',
    buckets: [0.1, 0.3, 0.5, 0.7, 0.8, 0.9, 0.95, 0.99, 1.0]
  }),

  sensorCalibrationDuration: new prometheus.Histogram({
    name: 'compass_calibration_duration_seconds',
    help: 'Time taken for sensor calibration',
    buckets: [1, 5, 10, 30, 60, 120]
  }),

  apiResponseTime: new prometheus.Histogram({
    name: 'compass_api_response_time_seconds',
    help: 'Response time for compass API endpoints',
    labelNames: ['endpoint', 'method', 'status_code']
  }),

  errorRate: new prometheus.Counter({
    name: 'compass_errors_total',
    help: 'Total number of compass-related errors',
    labelNames: ['type', 'component']
  })
};

// Middleware for API monitoring
export const monitoringMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const startTime = Date.now();

  res.on('finish', () => {
    const duration = (Date.now() - startTime) / 1000;
    const endpoint = req.route?.path || req.path;

    compassMetrics.apiResponseTime
      .labels(endpoint, req.method, res.statusCode.toString())
      .observe(duration);
  });

  next();
};

// Health check endpoint
export async function GET() {
  try {
    // Check database connectivity
    const dbHealth = await checkDatabaseHealth();

    // Check Redis connectivity
    const redisHealth = await checkRedisHealth();

    // Check external services
    const aiServiceHealth = await checkAIServiceHealth();

    const health = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: dbHealth,
        redis: redisHealth,
        ai: aiServiceHealth
      }
    };

    return NextResponse.json(health);
  } catch (error) {
    return NextResponse.json(
      { status: 'unhealthy', error: error.message },
      { status: 503 }
    );
  }
}

// Error tracking
class CompassErrorReporter {
  static reportError(error: Error, context: Record<string, any>) {
    // Increment error counter
    compassMetrics.errorRate
      .labels(error.constructor.name, context.component || 'unknown')
      .inc();

    // Send to error tracking service (Sentry, etc.)
    if (process.env.NODE_ENV === 'production') {
      console.error('Compass Error:', {
        error: error.message,
        stack: error.stack,
        context
      });
    }
  }
}

// Usage in components
export const useSensorFusion = (config: SensorConfig) => {
  // ... existing code ...

  const handleSensorError = useCallback((error: Error) => {
    CompassErrorReporter.reportError(error, {
      component: 'SensorFusion',
      config,
      userAgent: navigator.userAgent
    });
  }, [config]);

  // ... rest of hook ...
};
```

This comprehensive technical documentation provides the foundation for successfully integrating the FengShuiCompass into the QiFlow AI platform. The architecture supports both traditional feng shui accuracy and modern web application requirements, ensuring a professional-grade compass solution for feng shui practitioners and enthusiasts.